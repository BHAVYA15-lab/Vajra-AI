import os, re

files_to_check = [
    'data_generator/generate_logs.py',
    'models/detection_model.py',
    'models/classifier.py',
    'explainability/explainer.py',
    'Home.py',
    'pages/1_Live_Threat_Feed.py',
    'pages/2_Entity_Profiler.py',
    'pages/3_Threat_Analytics.py',
    'utils/data_loader.py',
    'utils/theme.py'
]

keywords = ['requests', 'urllib', 'http', 'socket', 'aiohttp', 'httpx', 'fetch', 'anthropic', 'openai', 'google', 'api.']

print("=== NETWORK CALL & API ACCESS AUDIT RESULTS ===")
total_network_calls = 0

for filepath in files_to_check:
    print(f"\nFile: {filepath}")
    if not os.path.exists(filepath):
        print("  [NOT FOUND]")
        continue
        
    with open(filepath, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        
    file_matches = []
    for idx, line in enumerate(lines, 1):
        # Ignore comments or markdown strings containing URLs for display (e.g. mitre links in comments)
        line_clean = line.strip()
        for kw in keywords:
            if re.search(r'\b' + re.escape(kw) + r'\b', line_clean, re.IGNORECASE):
                # Filter out pure comments or UI strings if not actual network imports/calls
                file_matches.append((idx, line_clean, kw))
                
    if not file_matches:
        print("  --> NO NETWORK CALLS FOUND (100% Offline Local Pipeline)")
    else:
        for line_num, code, kw in file_matches:
            print(f"  Line {line_num:<4} [{kw}]: {code}")
            # Check if it's an actual network request vs string variable
            if 'import requests' in code or 'urllib' in code or 'socket' in code or 'httpx' in code:
                total_network_calls += 1

print("\n" + "="*70)
print(f"TOTAL ACTIVE NETWORK / REMOTE API CALLS IN CORE ENGINE: {total_network_calls}")
