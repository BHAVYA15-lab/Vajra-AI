import os, sys
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether, HRFlowable
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfgen import canvas

class NumberedCanvas(canvas.Canvas):
    """Canvas for adding background theme and slide numbers."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_decorations(num_pages)
            super().showPage()
        super().save()

    def draw_page_decorations(self, page_count):
        self.saveState()
        # Draw dark slate background
        self.setFillColor(colors.HexColor('#0a0c12'))
        self.rect(0, 0, 792, 612, fill=True, stroke=False)
        
        # Header banner line
        self.setStrokeColor(colors.HexColor('#232840'))
        self.setLineWidth(1)
        self.line(40, 565, 752, 565)
        
        # Header title tag
        self.setFillColor(colors.HexColor('#4f7cff'))
        self.setFont("Helvetica-Bold", 10)
        self.drawString(40, 575, "VAJRA AI — HACKATHON PRESENTATION")
        
        # Footer line and page numbers
        self.line(40, 45, 752, 45)
        self.setFillColor(colors.HexColor('#8b90a8'))
        self.setFont("Helvetica", 9)
        self.drawString(40, 30, "Cascaded Behavioral Threat Detection & Response | Hackathon Submission")
        self.drawRightString(752, 30, f"Slide {self._pageNumber} of {page_count}")
        self.restoreState()

def build_pdf(filename="reports/Vajra_AI_Presentation.pdf"):
    doc = SimpleDocTemplate(
        filename,
        pagesize=landscape(letter),
        leftMargin=40,
        rightMargin=40,
        topMargin=55,
        bottomMargin=55
    )
    
    styles = getSampleStyleSheet()
    
    # Custom Dark Theme Paragraph Styles
    title_style = ParagraphStyle(
        'SlideTitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=22,
        leading=26,
        textColor=colors.HexColor('#e8eaf2'),
        spaceAfter=12
    )
    
    subtitle_style = ParagraphStyle(
        'SlideSubtitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=13,
        leading=16,
        textColor=colors.HexColor('#4f7cff'),
        spaceAfter=15
    )
    
    section_heading = ParagraphStyle(
        'SectionHeading',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=13,
        leading=16,
        textColor=colors.HexColor('#22d3a4'),
        spaceBefore=8,
        spaceAfter=6
    )
    
    body_style = ParagraphStyle(
        'BodyDark',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#e8eaf2'),
        spaceAfter=6
    )
    
    bullet_style = ParagraphStyle(
        'BulletDark',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#e8eaf2'),
        leftIndent=12,
        spaceAfter=4
    )
    
    code_style = ParagraphStyle(
        'CodeDark',
        parent=styles['Normal'],
        fontName='Courier',
        fontSize=8.5,
        leading=11,
        textColor=colors.HexColor('#22d3a4'),
        spaceAfter=4
    )

    story = []

    # =========================================================================
    # SLIDE 1: TITLE PAGE
    # =========================================================================
    story.append(Paragraph("AI-Powered Behavioral Anomaly Detection for Cybersecurity", title_style))
    story.append(Paragraph("Vajra AI — Cascaded Behavioral Threat Detection & Response", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#2e3450'), spaceAfter=15))
    
    t1_data = [
        [Paragraph("<b>Attribute</b>", section_heading), Paragraph("<b>Details</b>", section_heading)],
        [Paragraph("<b>Problem Statement Title</b>", body_style), Paragraph("AI-Powered Behavioral Anomaly Detection for Cybersecurity", body_style)],
        [Paragraph("<b>Theme</b>", body_style), Paragraph("Cybersecurity / Smart Automation (TO BE CONFIRMED BY USER)", body_style)],
        [Paragraph("<b>PS Category</b>", body_style), Paragraph("Software", body_style)],
        [Paragraph("<b>Problem Statement ID</b>", body_style), Paragraph("TO BE FILLED — USER MUST PROVIDE (Check Hackathon Portal)", body_style)],
        [Paragraph("<b>Student Name</b>", body_style), Paragraph("TO BE FILLED — USER MUST PROVIDE", body_style)],
        [Paragraph("<b>Student ID</b>", body_style), Paragraph("TO BE FILLED — USER MUST PROVIDE", body_style)],
    ]
    t1 = Table(t1_data, colWidths=[200, 512])
    t1.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#141720')),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#232840')),
        ('PADDING', (0,0), (-1,-1), 8),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    story.append(t1)
    story.append(PageBreak())

    # =========================================================================
    # SLIDE 2: IDEA TITLE — PROPOSED SOLUTION
    # =========================================================================
    story.append(Paragraph("Idea Title: Proposed Solution", title_style))
    story.append(Paragraph("Vajra AI — Cascaded Behavioral Threat Detection & Response", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#2e3450'), spaceAfter=10))

    story.append(Paragraph("System Overview", section_heading))
    story.append(Paragraph("• Models 14-day trailing access baselines per entity without hardcoded IP blacklists.", bullet_style))
    story.append(Paragraph("• Detects complex multi-stage attacks via a 2-tier Staged Cascade Pipeline.", bullet_style))
    story.append(Paragraph("• Maps anomalies directly to official MITRE ATT&CK techniques with remediation steps.", bullet_style))
    story.append(Paragraph("• Displays operational Risk (0-100) vs. ML Confidence (0-100%) on a Streamlit SOC Console.", bullet_style))

    story.append(Paragraph("Addressing Problem Statement Requirements", section_heading))
    story.append(Paragraph("• <b>Sequential Behavior</b>: Tracks K=5 event windows and 9D deviation feature matrix.", bullet_style))
    story.append(Paragraph("• <b>Extreme Class Imbalance</b>: Evaluated with balanced Random Forest and alert budget capacity.", bullet_style))
    story.append(Paragraph("• <b>Concept Drift</b>: Updates baselines via Exponential Moving Average (alpha=0.05) on benign logs.", bullet_style))
    story.append(Paragraph("• <b>Explainability & Cold-Start</b>: SHAP feature drivers + peer-group fallback (70% confidence cap).", bullet_style))

    story.append(Paragraph("Innovation & Uniqueness", section_heading))
    story.append(Paragraph("• <b>Staged Cascade</b>: Fast Isolation Forest cuts deep PyTorch LSTM workload by 96.88%.", bullet_style))
    story.append(Paragraph("• <b>Physics-Rule Hybrid</b>: Hard-coded velocity check (>900 km/h) flags impossible_travel with 100% accuracy.", bullet_style))
    story.append(Paragraph("• <b>Alert Budget Tuning</b>: Evaluates recall against analyst capacity (Top 1% = 75.61% Recall / 0.89% FPR).", bullet_style))
    story.append(PageBreak())

    # =========================================================================
    # SLIDE 3: TECHNICAL APPROACH
    # =========================================================================
    story.append(Paragraph("Technical Approach & Architecture", title_style))
    story.append(Paragraph("Technology Stack, Cascade Pipeline & 9D Feature Engine", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#2e3450'), spaceAfter=10))

    t3_data = [
        [Paragraph("<b>Tech Stack</b>", section_heading), Paragraph("<b>Pipeline Flow Diagram</b>", section_heading)],
        [
            Paragraph("• <b>Language</b>: Python 3.12<br/>"
                      "• <b>Data</b>: pandas 2.1.4, NumPy 1.26.2<br/>"
                      "• <b>ML Engine</b>: scikit-learn 1.7.2<br/>"
                      "• <b>Deep Learning</b>: PyTorch 2.13.0<br/>"
                      "• <b>Dashboard</b>: Streamlit 1.60.0, Plotly<br/>"
                      "• <b>Explainability</b>: SHAP 0.44.1", body_style),
            Paragraph("<b>[ Log Stream ]</b> (91,805 Events)<br/>"
                      "  └─► <b>[ Baseline Profiler ]</b> (14-Day EMA, alpha=0.05)<br/>"
                      "       └─► <b>[ 9D Feature Matrix ]</b><br/>"
                      "            └─► <b>[ Stage 1: Isolation Forest ]</b> (Inliers ~97% Safe)<br/>"
                      "                 └─► <b>[ Stage 2: PyTorch LSTM ]</b> (Candidates ~3%)<br/>"
                      "                      └─► <b>[ Classifier & Physics Override ]</b><br/>"
                      "                           └─► <b>[ Risk & MITRE Engine ]</b> ──► <b>[ Streamlit UI ]</b>", body_style)
        ]
    ]
    t3 = Table(t3_data, colWidths=[280, 432])
    t3.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#141720')),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#232840')),
        ('PADDING', (0,0), (-1,-1), 8),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    story.append(t3)

    story.append(Paragraph("Core 9D Baseline Deviation Features", section_heading))
    story.append(Paragraph("1. geo_distance_km | 2. time_of_day_zscore | 3. resource_novelty | 4. session_duration_zscore | 5. auth_failure_rate_trailing", bullet_style))
    story.append(Paragraph("6. source_ip_entity_fanout | 7. command_sequence_novelty | 8. fingerprint_mismatch | 9. is_cold_start", bullet_style))
    story.append(PageBreak())

    # =========================================================================
    # SLIDE 4: FEASIBILITY AND VIABILITY
    # =========================================================================
    story.append(Paragraph("Feasibility & Viability Analysis", title_style))
    story.append(Paragraph("Benchmarked Performance, Technical Limitations & Mitigation Strategies", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#2e3450'), spaceAfter=10))

    story.append(Paragraph("Benchmarked Working Prototype Results", section_heading))
    story.append(Paragraph("• <b>Prototype Load Latency</b>: 4-page Streamlit SOC console loads complete pipeline data in 6.8s.", bullet_style))
    story.append(Paragraph("• <b>Workload Reduction</b>: Stage 1 filters 96.88% of logs; Stage 2 LSTM evaluates only 3.12% suspicious pool.", bullet_style))
    story.append(Paragraph("• <b>Top 1.0% Alert Budget Performance</b> (Temporal Split: Days 1-21 Train, Days 22-30 Test):", bullet_style))
    story.append(Paragraph("&nbsp;&nbsp;&nbsp;&nbsp;<b>System Recall</b>: 75.61% (31/41 attacks) | <b>False Positive Rate</b>: 0.89% (245 FPs) | <b>Precision</b>: 11.23%", body_style))

    t4_data = [
        [Paragraph("<b>Identified Technical Risks / Limitations</b>", section_heading), Paragraph("<b>Engineering Mitigation Strategies</b>", section_heading)],
        [
            Paragraph("• <b>Base-Rate Fallacy</b>: 0.15% attack prevalence causes false alarms to outnumber true attacks.<br/>"
                      "• <b>Asset Severity Bias</b>: 10 low-asset attacks (sev=0.3) fall below top 1% risk cutoff.<br/>"
                      "• <b>Low Sample Sizes</b>: 5 of 6 attack classes have N <= 5 in strict temporal split.<br/>"
                      "• <b>Untested Physics Range</b>: Speed rule untested in 900-5000 km/h flight layover range.", body_style),
            Paragraph("• <b>Alert Budget Tuning</b>: Tune operating cutoffs to analyst review capacity rather than static rules.<br/>"
                      "• <b>Dual Ranking Modes</b>: Provide toggle between Severity-Risk Rank and Pure Anomaly Rank.<br/>"
                      "• <b>Active Learning Loop</b>: Log analyst feedback (Confirm/Dismiss) to retrain baseline profiles.<br/>"
                      "• <b>Real-World Calibration</b>: Calibrate speed threshold against airline flight data prior to deployment.", body_style)
        ]
    ]
    t4 = Table(t4_data, colWidths=[350, 362])
    t4.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#141720')),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#232840')),
        ('PADDING', (0,0), (-1,-1), 8),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    story.append(t4)
    story.append(PageBreak())

    # =========================================================================
    # SLIDE 5: ARTIFACTS
    # =========================================================================
    story.append(Paragraph("Artifacts: Dashboard & Core Code Logic", title_style))
    story.append(Paragraph("Streamlit Console Views & Representative Pipeline Engine Code", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#2e3450'), spaceAfter=10))

    t5_data = [
        [Paragraph("<b>Interactive Dashboard Screenshots</b>", section_heading), Paragraph("<b>Representative Engine Code Snippet</b>", section_heading)],
        [
            Paragraph("1. <b>`reports/screenshots/01_home_dashboard.png`</b><br/>"
                      "   • Header, LIVE indicator, pipeline status strip, KPIs.<br/><br/>"
                      "2. <b>`reports/screenshots/02_live_threat_feed.png`</b><br/>"
                      "   • Ranked alert queue table, inline reasons, 🔴 LIVE mode.<br/><br/>"
                      "3. <b>`reports/screenshots/03_triage_inspector.png`</b><br/>"
                      "   • SHAP attributions, Risk/Confidence gauges, MITRE checklist.<br/><br/>"
                      "4. <b>`reports/screenshots/04_threat_analytics.png`</b><br/>"
                      "   • Cascade benchmark charts & alert budget trade-off table.", body_style),
            Paragraph("<b>File: utils/data_loader.py</b> (Physics Override & Risk Engine)<br/><br/>"
                      "<code># 1. Physics Impossible-Travel Hard Override Check<br/>"
                      "is_physics_impossible = (feat_dict.get('is_physics_impossible_travel', 0.0) == 1.0)<br/>"
                      "if is_physics_impossible:<br/>"
                      "    pred_attack = 'impossible_travel'<br/>"
                      "    conf_score = 99.9<br/>"
                      "    sev_label = 'CRITICAL'<br/>"
                      "    risk_score = max(risk_score, 88.0)<br/><br/>"
                      "# 2. Composite Risk Score Formula (0-100)<br/>"
                      "# Risk = 40% Anomaly + 35% Max Deviation + 25% Severity Weight<br/>"
                      "risk_score = (0.40 * norm_anom) + (0.35 * max_dev) + (0.25 * sev_weight * 100.0)<br/>"
                      "risk_score = float(np.clip(risk_score, 0.0, 100.0))</code>", code_style)
        ]
    ]
    t5 = Table(t5_data, colWidths=[330, 382])
    t5.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#141720')),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#232840')),
        ('PADDING', (0,0), (-1,-1), 8),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    story.append(t5)
    story.append(PageBreak())

    # =========================================================================
    # SLIDE 6: RESEARCH AND REFERENCES
    # =========================================================================
    story.append(Paragraph("Research & References", title_style))
    story.append(Paragraph("Standards, Cited Literature & Architectural Justifications", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#2e3450'), spaceAfter=15))

    t6_data = [
        [Paragraph("<b>Domain / Method</b>", section_heading), Paragraph("<b>Reference & Architectural Justification</b>", section_heading)],
        [
            Paragraph("<b>MITRE ATT&CK Framework</b>", body_style),
            Paragraph("Standard taxonomy for adversary tactics and techniques (<code>https://attack.mitre.org/</code>). Used to map detected threats to Technique IDs (T1110, T1036, T1078, T1021, T1041).", body_style)
        ],
        [
            Paragraph("<b>Stage 1: Isolation Forest</b>", body_style),
            Paragraph("Liu, F. T., Ting, K. M., & Zhou, Z. H. (2008). <i>Isolation Forest</i>. IEEE ICDM. Justifies low-latency ($<1.0\\text{ms}$) tabular filtering on 100% of incoming logs.", body_style)
        ],
        [
            Paragraph("<b>Stage 2: PyTorch LSTM</b>", body_style),
            Paragraph("Malhotra, P., et al. (2016). <i>LSTM-based Encoder-Decoder for Multi-sensor Anomaly Detection</i>. arXiv:1607.00148. Justifies LSTM sequence autoencoders over Transformers for short K=5 windows.", body_style)
        ],
        [
            Paragraph("<b>EMA Concept Drift</b>", body_style),
            Paragraph("Gama, J., et al. (2014). <i>A survey on concept drift adaptation</i>. ACM Computing Surveys. Justifies updating trailing baseline profiles with alpha=0.05 on confirmed benign traffic.", body_style)
        ],
        [
            Paragraph("<b>Explainability (SHAP)</b>", body_style),
            Paragraph("Lundberg, S. M., & Lee, S. I. (2017). <i>A Unified Approach to Interpreting Model Predictions</i>. NIPS. Justifies game-theoretic feature attribution scoring for SOC triage cards.", body_style)
        ],
    ]
    t6 = Table(t6_data, colWidths=[180, 532])
    t6.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#141720')),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#232840')),
        ('PADDING', (0,0), (-1,-1), 8),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    story.append(t6)

    doc.build(story, canvasmaker=NumberedCanvas)

if __name__ == "__main__":
    os.makedirs("reports", exist_ok=True)
    out_pdf = "reports/Vajra_AI_Presentation.pdf"
    build_pdf(out_pdf)
    # Also save to root directory for easy access
    build_pdf("Vajra_AI_Presentation.pdf")
    print(f"SUCCESS: Generated PDF presentation '{out_pdf}' and 'Vajra_AI_Presentation.pdf'")

